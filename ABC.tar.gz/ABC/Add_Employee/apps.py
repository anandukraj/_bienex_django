from django.apps import AppConfig


class AddEmployeeConfig(AppConfig):
    name = 'Add_Employee'
